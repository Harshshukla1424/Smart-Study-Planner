const backendUrl = "http://localhost:8080/tasks";

async function fetchTasks() {
  const res = await fetch(backendUrl);
  const tasks = await res.json();
  const taskList = document.getElementById("taskList");
  taskList.innerHTML = "";
  tasks.forEach((task) => {
    const li = document.createElement("li");
    li.textContent = task.title;
    li.onclick = () => deleteTask(task.id);
    taskList.appendChild(li);
  });
}

async function addTask() {
  const title = document.getElementById("taskInput").value;
  await fetch(backendUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title }),
  });
  fetchTasks();
}

async function deleteTask(id) {
  await fetch(`${backendUrl}/${id}`, { method: "DELETE" });
  fetchTasks();
}

window.onload = fetchTasks;
